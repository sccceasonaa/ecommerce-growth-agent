import json
from pathlib import Path

import pandas as pd
import streamlit as st

from agents import (
    AdStrategyAgent,
    CopywritingAgent,
    ProductInfoParserAgent,
    ReviewOptimizationAgent,
    SellingPointAgent,
)
from llm_client import LLMClient
from optimizer import simulate_ab_test, variants_to_dataframe


st.set_page_config(
    page_title="电商运营 Agent MVP",
    page_icon="🛒",
    layout="wide",
)

SAMPLE_PATH = Path("data/sample_product.json")


def load_sample() -> dict:
    with SAMPLE_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def run_pipeline(product: dict, seed: int = 42) -> dict:
    llm = LLMClient()

    parser_agent = ProductInfoParserAgent(llm)
    selling_agent = SellingPointAgent(llm)
    copy_agent = CopywritingAgent(llm)
    strategy_agent = AdStrategyAgent(llm)
    review_agent = ReviewOptimizationAgent(llm)

    parsed = parser_agent.run(product)
    selling = selling_agent.run(parsed.data)
    copywriting = copy_agent.run(parsed.data, selling.data)
    strategy = strategy_agent.run(parsed.data, copywriting.data, selling.data)
    ab_results = simulate_ab_test(strategy.data["audience_segments"], seed=seed)
    review = review_agent.run(ab_results)

    return {
        "parsed": parsed,
        "selling": selling,
        "copywriting": copywriting,
        "strategy": strategy,
        "ab_results": ab_results,
        "review": review,
    }


def render_agent_card(result):
    with st.container(border=True):
        st.subheader(result.agent_name)
        st.write(result.summary)
        st.json(result.data, expanded=False)


def render_titles(titles):
    st.markdown("#### 商品标题")
    for item in titles:
        st.write(f"**{item.get('type', '标题')}：** {item.get('text', '')}")


def render_detail_page(copy_data):
    st.markdown("#### 详情页文案")
    detail = copy_data.get("detail_page_copy", {})
    st.success(detail.get("hero", ""))
    st.write(detail.get("sub_hero", ""))
    for section in detail.get("sections", []):
        with st.container(border=True):
            st.markdown(f"**{section.get('headline', '')}**")
            st.write(section.get("body", ""))
    st.info(detail.get("cta", ""))


def render_video_scripts(scripts):
    st.markdown("#### 短视频脚本")
    for script in scripts:
        with st.expander(script.get("name", "短视频脚本"), expanded=False):
            st.write(f"目标人群：{script.get('target_audience', '')}")
            for shot in script.get("shots", []):
                st.write(f"- {shot}")


def render_slogans(slogans):
    st.markdown("#### 广告语")
    for slogan in slogans:
        st.write(f"**{slogan.get('scenario', '')}：** {slogan.get('text', '')}")


def render_strategy(strategy_data):
    st.markdown("#### 分人群投放素材")
    for seg in strategy_data.get("audience_segments", []):
        with st.container(border=True):
            st.markdown(f"### {seg.get('segment')}")
            st.write(f"**痛点：** {seg.get('pain_point')}")
            st.write(f"**主卖点：** {seg.get('main_selling_point')}")
            material = seg.get("material_version", {})
            st.write(f"**标题：** {material.get('title')}")
            st.write(f"**广告语：** {material.get('slogan')}")
            st.write(f"**视觉方向：** {material.get('visual')}")
            st.write(f"**CTA：** {material.get('cta')}")

    st.markdown("#### 渠道建议")
    for item in strategy_data.get("channel_recommendations", []):
        st.write(f"**{item.get('channel')}：** {item.get('content_type')}。{item.get('reason')}")


def render_ab_results(ab_results):
    df = variants_to_dataframe(ab_results)
    if df.empty:
        st.warning("暂无 A/B 测试数据")
        return

    st.markdown("#### A/B 测试结果")
    st.dataframe(df, use_container_width=True)

    winner = ab_results.get("winner")
    if winner:
        st.success(
            f"当前优胜版本：{winner['version_id']}｜人群：{winner['segment']}｜"
            f"综合评分：{winner['score']}｜ROAS：{winner['roas']}"
        )

    metric = st.selectbox(
        "选择要查看的指标",
        ["点击率", "转化率", "加购率", "CPA", "ROAS", "综合评分"],
        index=5,
    )

    chart_df = df[["版本", metric]].set_index("版本")
    st.bar_chart(chart_df)


def render_optimization(review_data):
    st.markdown("#### 复盘诊断")
    for item in review_data.get("diagnosis", []):
        st.write(f"- {item}")

    st.markdown("#### 下一步动作")
    for item in review_data.get("next_actions", []):
        st.write(f"- {item}")

    st.markdown("#### 下一轮可测试版本")
    for item in review_data.get("recommended_next_round", []):
        with st.container(border=True):
            st.write(f"**{item.get('version_id')}｜{item.get('direction')}**")
            st.write(item.get("copy"))


st.title("🛒 电商运营 Agent：自动生成商品文案 + 投放素材 + A/B 优化")
st.caption("一个用于展示“AI 驱动业务增长”的多 Agent 闭环系统 MVP")

with st.sidebar:
    st.header("运行设置")
    seed = st.number_input("A/B 测试随机种子", min_value=1, max_value=9999, value=42)
    st.write("没有配置 OpenAI API Key 时，系统会自动使用本地规则生成。")
    use_sample = st.button("加载示例商品", use_container_width=True)

if "product_text" not in st.session_state:
    st.session_state.product_text = json.dumps(load_sample(), ensure_ascii=False, indent=2)

if use_sample:
    st.session_state.product_text = json.dumps(load_sample(), ensure_ascii=False, indent=2)

tab_input, tab_result, tab_ab, tab_report = st.tabs([
    "1. 商品输入",
    "2. Agent 生成结果",
    "3. A/B 测试",
    "4. 复盘优化",
])

with tab_input:
    st.subheader("输入商品信息")
    st.write("可以直接编辑 JSON。建议包含商品名称、品类、价格、参数、竞品描述、用户评价、业务目标。")

    st.session_state.product_text = st.text_area(
        "商品资料 JSON",
        value=st.session_state.product_text,
        height=520,
    )

    run_btn = st.button("运行完整 Agent 流程", type="primary", use_container_width=True)

    if run_btn:
        try:
            product = json.loads(st.session_state.product_text)
            st.session_state.pipeline_result = run_pipeline(product, seed=int(seed))
            st.success("Agent 流程已完成，请查看后面的标签页。")
        except json.JSONDecodeError as exc:
            st.error(f"JSON 格式错误：{exc}")
        except Exception as exc:
            st.error(f"运行失败：{exc}")

if "pipeline_result" not in st.session_state:
    st.info("请先在「商品输入」页点击运行。")
else:
    result = st.session_state.pipeline_result

    with tab_result:
        st.subheader("Agent 运行链路")
        col1, col2 = st.columns(2)
        with col1:
            render_agent_card(result["parsed"])
            render_agent_card(result["selling"])
        with col2:
            render_agent_card(result["copywriting"])
            render_agent_card(result["strategy"])

        st.divider()
        st.subheader("可直接用于运营的内容")
        copy_data = result["copywriting"].data
        render_titles(copy_data.get("titles", []))
        render_detail_page(copy_data)
        render_video_scripts(copy_data.get("short_video_scripts", []))
        render_slogans(copy_data.get("ad_slogans", []))

        st.divider()
        st.subheader("投放素材版本")
        render_strategy(result["strategy"].data)

    with tab_ab:
        render_ab_results(result["ab_results"])

    with tab_report:
        render_optimization(result["review"].data)
