import json
import re
from dataclasses import dataclass
from typing import Any, Dict, List

from llm_client import LLMClient


def safe_join(items: List[str], sep: str = "；") -> str:
    return sep.join([str(x).strip() for x in items if str(x).strip()])


def normalize_text(value: Any) -> str:
    if isinstance(value, dict):
        return "；".join([f"{k}:{v}" for k, v in value.items()])
    if isinstance(value, list):
        return "；".join([str(x) for x in value])
    return str(value or "")


@dataclass
class AgentResult:
    agent_name: str
    summary: str
    data: Dict[str, Any]


class BaseAgent:
    def __init__(self, llm: LLMClient | None = None):
        self.llm = llm or LLMClient()

    @property
    def name(self) -> str:
        return self.__class__.__name__


class ProductInfoParserAgent(BaseAgent):
    """
    商品信息解析 Agent：
    读取商品参数、竞品描述、用户评价，并转换为统一结构。
    """

    def run(self, raw_product: Dict[str, Any]) -> AgentResult:
        product_name = raw_product.get("product_name", "未命名商品")
        category = raw_product.get("category", "未分类")
        price = raw_product.get("price", "未填写")
        parameters = raw_product.get("parameters", {})
        competitor_descriptions = raw_product.get("competitor_descriptions", [])
        user_reviews = raw_product.get("user_reviews", [])
        target_market = raw_product.get("target_market", "")
        business_goal = raw_product.get("business_goal", "")

        structured = {
            "product_name": product_name,
            "category": category,
            "price": price,
            "target_market": target_market,
            "business_goal": business_goal,
            "parameters": parameters,
            "competitor_descriptions": competitor_descriptions,
            "user_reviews": user_reviews,
            "basic_tags": self._build_basic_tags(raw_product),
        }

        summary = (
            f"已解析商品《{product_name}》，品类为 {category}，价格为 {price}。"
            f"共读取 {len(parameters)} 个商品参数、{len(competitor_descriptions)} 条竞品信息、"
            f"{len(user_reviews)} 条用户评价。"
        )

        return AgentResult(
            agent_name="商品信息解析 Agent",
            summary=summary,
            data=structured,
        )

    def _build_basic_tags(self, product: Dict[str, Any]) -> List[str]:
        text = normalize_text(product)
        tag_rules = {
            "便携": ["轻", "小巧", "便携", "迷你", "520g"],
            "长续航": ["续航", "10小时", "电池", "充电"],
            "低噪音": ["低噪", "安静", "噪音", "38dB"],
            "智能": ["AI", "智能", "自动", "感应"],
            "专业": ["专业", "运动", "恢复", "筋膜", "按摩头"],
            "办公人群": ["久坐", "肩颈", "办公室", "办公"],
        }

        tags = []
        for tag, keywords in tag_rules.items():
            if any(keyword.lower() in text.lower() for keyword in keywords):
                tags.append(tag)

        return tags or ["新品", "电商运营", "待测试"]


class SellingPointAgent(BaseAgent):
    """
    卖点提炼 Agent：
    从商品参数、竞品描述、用户评价中找出核心卖点和用户关心点。
    """

    def run(self, parsed_product: Dict[str, Any]) -> AgentResult:
        llm_text = self._try_llm(parsed_product)
        if llm_text and not llm_text.startswith("[LLM调用失败"):
            result = {
                "llm_analysis": llm_text,
                "core_selling_points": self._rule_core_points(parsed_product),
                "customer_concerns": self._extract_customer_concerns(parsed_product),
                "differentiation": self._extract_differentiation(parsed_product),
            }
        else:
            result = {
                "core_selling_points": self._rule_core_points(parsed_product),
                "customer_concerns": self._extract_customer_concerns(parsed_product),
                "differentiation": self._extract_differentiation(parsed_product),
            }
            if llm_text:
                result["llm_status"] = llm_text

        summary = "已完成卖点提炼：包括核心卖点、用户关心点、竞品差异化方向。"
        return AgentResult("卖点提炼 Agent", summary, result)

    def _try_llm(self, parsed_product: Dict[str, Any]) -> str | None:
        system = "你是资深电商运营专家，擅长从商品资料中提炼可转化的卖点。"
        user = f"""
请根据以下商品资料，输出：
1. 核心卖点
2. 用户最关心点
3. 相比竞品的差异化
4. 可用于投放测试的卖点方向

商品资料：
{json.dumps(parsed_product, ensure_ascii=False, indent=2)}
"""
        return self.llm.chat(system, user, temperature=0.5)

    def _rule_core_points(self, product: Dict[str, Any]) -> List[Dict[str, str]]:
        params_text = normalize_text(product.get("parameters", {}))
        reviews_text = normalize_text(product.get("user_reviews", []))
        all_text = params_text + "；" + reviews_text

        candidates = []

        if any(k in all_text for k in ["AI", "智能", "自动", "感应"]):
            candidates.append({
                "point": "AI 智能调节",
                "evidence": "商品参数中包含 AI 压力感应或自动调节能力",
                "conversion_angle": "降低用户选择档位的学习成本，突出智能、省心"
            })

        if any(k in all_text for k in ["低噪", "安静", "38dB", "噪音"]):
            candidates.append({
                "point": "低噪音使用体验",
                "evidence": "参数或评价中出现低噪、安静、不会吵到别人等信息",
                "conversion_angle": "适合宿舍、办公室、家庭夜间等安静场景"
            })

        if any(k in all_text for k in ["续航", "10小时", "一周充一次"]):
            candidates.append({
                "point": "长续航",
                "evidence": "参数或评价中体现较长续航",
                "conversion_angle": "减少频繁充电焦虑，适合高频使用人群"
            })

        if any(k in all_text for k in ["轻", "520g", "女生", "不累", "便携"]):
            candidates.append({
                "point": "轻量便携",
                "evidence": "商品重量较轻，用户评价中出现拿着不累",
                "conversion_angle": "适合女性用户、办公室用户、外出携带"
            })

        if any(k in all_text for k in ["肩颈", "久坐", "小腿", "运动", "恢复"]):
            candidates.append({
                "point": "多场景放松恢复",
                "evidence": "评价中出现肩颈、久坐、运动后、小腿等使用场景",
                "conversion_angle": "覆盖办公放松和运动恢复双场景，提高受众范围"
            })

        if not candidates:
            candidates.append({
                "point": "新品综合体验",
                "evidence": "根据商品基础信息生成通用卖点",
                "conversion_angle": "通过价格、功能、场景组合测试用户兴趣"
            })

        return candidates

    def _extract_customer_concerns(self, product: Dict[str, Any]) -> List[str]:
        reviews = product.get("user_reviews", [])
        text = normalize_text(reviews)
        concerns = []

        concern_rules = {
            "使用后是否真的能缓解酸痛": ["酸痛", "放松", "舒服"],
            "噪音会不会影响别人": ["声音", "噪音", "吵", "安静"],
            "拿着会不会累": ["重量", "女生", "不累", "轻"],
            "续航是否够用": ["续航", "充电", "一周"],
            "配件是否足够专业": ["按摩头", "配件", "专业"],
        }

        for concern, keywords in concern_rules.items():
            if any(k in text for k in keywords):
                concerns.append(concern)

        return concerns or ["价格是否合理", "效果是否明显", "是否适合自己的使用场景"]

    def _extract_differentiation(self, product: Dict[str, Any]) -> List[str]:
        competitors = normalize_text(product.get("competitor_descriptions", []))
        diff = []

        if "噪音" in competitors or "噪" in competitors:
            diff.append("相比强调大力度但噪音偏高的竞品，可突出低噪音和舒适体验。")
        if "价格较高" in competitors or "高" in competitors:
            diff.append("相比高价专业竞品，可突出专业体验与价格平衡。")
        if "续航较短" in competitors or "档位较少" in competitors:
            diff.append("相比轻便但续航短、档位少的竞品，可突出续航、档位和综合配置。")

        return diff or ["通过场景化内容和用户评价证据建立差异化。"]


class CopywritingAgent(BaseAgent):
    """
    文案生成 Agent：
    生成标题、详情页文案、短视频脚本、广告语。
    """

    def run(self, parsed_product: Dict[str, Any], selling_points: Dict[str, Any]) -> AgentResult:
        llm_text = self._try_llm(parsed_product, selling_points)

        product_name = parsed_product.get("product_name", "新品")
        core_points = selling_points.get("core_selling_points", [])
        point_names = [p["point"] if isinstance(p, dict) else str(p) for p in core_points]

        generated = {
            "titles": self._generate_titles(product_name, point_names),
            "detail_page_copy": self._generate_detail_copy(product_name, core_points),
            "short_video_scripts": self._generate_video_scripts(product_name, point_names),
            "ad_slogans": self._generate_slogans(product_name, point_names),
        }

        if llm_text and not llm_text.startswith("[LLM调用失败"):
            generated["llm_generated_copy"] = llm_text
        elif llm_text:
            generated["llm_status"] = llm_text

        summary = "已生成商品标题、详情页文案、短视频脚本和广告语。"
        return AgentResult("文案生成 Agent", summary, generated)

    def _try_llm(self, product: Dict[str, Any], selling_points: Dict[str, Any]) -> str | None:
        system = "你是电商增长文案专家，擅长写高点击、高转化、可测试的商品文案。"
        user = f"""
请基于商品资料和卖点分析，生成可直接用于电商运营的文案。
要求输出：
1. 5个商品标题
2. 详情页首屏文案
3. 3条广告语
4. 2个15秒短视频脚本
5. 每条文案适合测试的人群

商品资料：
{json.dumps(product, ensure_ascii=False, indent=2)}

卖点分析：
{json.dumps(selling_points, ensure_ascii=False, indent=2)}
"""
        return self.llm.chat(system, user, temperature=0.8)

    def _generate_titles(self, product_name: str, points: List[str]) -> List[Dict[str, str]]:
        templates = [
            ("功能卖点型", f"{product_name}｜{self._pick(points, 0)}，让放松更省心"),
            ("场景痛点型", f"久坐肩颈酸？试试这款 {product_name}"),
            ("对比突出型", f"低噪轻量长续航，{product_name} 不只大力"),
            ("人群精准型", f"给健身和办公人群的智能放松装备：{product_name}"),
            ("利益承诺型", f"运动后、下班后，用 {product_name} 快速找回轻松感"),
        ]
        return [{"type": t, "text": v} for t, v in templates]

    def _generate_detail_copy(self, product_name: str, core_points: List[Dict[str, str]]) -> Dict[str, Any]:
        hero = f"{product_name}，为高频运动与久坐办公人群打造的智能放松装备。"
        sections = []

        for item in core_points:
            point = item.get("point", "核心卖点")
            angle = item.get("conversion_angle", "提升使用体验")
            evidence = item.get("evidence", "来自商品参数和用户评价")
            sections.append({
                "headline": point,
                "body": f"{angle}。{evidence}，让用户在购买前更容易理解它的实际价值。",
            })

        return {
            "hero": hero,
            "sub_hero": "从商品信息到投放素材，围绕真实使用场景打造高转化表达。",
            "sections": sections,
            "cta": "立即体验智能放松，让恢复更轻松。"
        }

    def _generate_video_scripts(self, product_name: str, points: List[str]) -> List[Dict[str, Any]]:
        return [
            {
                "name": "办公肩颈场景 15 秒脚本",
                "target_audience": "久坐办公人群",
                "shots": [
                    "0-3秒：白领揉肩，字幕：坐一天，肩颈又酸了？",
                    f"3-7秒：拿出 {product_name}，展示轻量便携和低噪使用。",
                    f"7-12秒：肩颈、小臂、小腿多部位使用，字幕：{self._pick(points, 0)}。",
                    "12-15秒：放松表情 + CTA：下班后的放松交给它。"
                ]
            },
            {
                "name": "运动恢复场景 15 秒脚本",
                "target_audience": "健身和运动人群",
                "shots": [
                    "0-3秒：跑步或健身后小腿酸胀，字幕：运动后恢复别硬扛。",
                    f"3-8秒：使用 {product_name} 按摩小腿和大腿肌群。",
                    f"8-12秒：突出 {self._pick(points, 1)}，展示不同按摩头和档位。",
                    "12-15秒：字幕：训练后的恢复效率，也是一种竞争力。"
                ]
            }
        ]

    def _generate_slogans(self, product_name: str, points: List[str]) -> List[Dict[str, str]]:
        slogans = [
            ("低噪场景", f"安静放松，不打扰生活。"),
            ("智能场景", f"力度不用猜，智能更省心。"),
            ("运动恢复", f"练得认真，也要恢复得专业。"),
            ("办公人群", f"久坐后的酸痛感，交给 {product_name}。"),
            ("便携人群", f"轻装带走，随时恢复状态。"),
        ]
        return [{"scenario": s, "text": t} for s, t in slogans]

    def _pick(self, items: List[str], index: int) -> str:
        if not items:
            return "核心卖点"
        return items[index % len(items)]


class AdStrategyAgent(BaseAgent):
    """
    投放策略 Agent：
    针对不同人群输出不同素材版本。
    """

    def run(self, parsed_product: Dict[str, Any], copywriting: Dict[str, Any], selling_points: Dict[str, Any]) -> AgentResult:
        product_name = parsed_product.get("product_name", "新品")
        segments = self._build_segments(product_name, selling_points, copywriting)

        result = {
            "audience_segments": segments,
            "testing_plan": self._build_testing_plan(segments),
            "channel_recommendations": self._channel_recommendations(),
        }

        summary = "已生成分人群投放策略，包括素材版本、卖点方向、渠道建议和测试计划。"
        return AgentResult("投放策略 Agent", summary, result)

    def _build_segments(self, product_name: str, selling_points: Dict[str, Any], copywriting: Dict[str, Any]) -> List[Dict[str, Any]]:
        titles = copywriting.get("titles", [])
        slogans = copywriting.get("ad_slogans", [])

        return [
            {
                "segment": "久坐办公人群",
                "pain_point": "肩颈酸痛、想要低噪不打扰同事或家人",
                "main_selling_point": "低噪音 + 肩颈放松 + 轻量便携",
                "material_version": {
                    "title": self._get_text(titles, 1),
                    "slogan": "坐久了的酸痛感，下班前就该被解决。",
                    "visual": "办公室桌面、电脑旁、肩颈按摩特写",
                    "cta": "立即缓解久坐酸痛"
                }
            },
            {
                "segment": "健身运动人群",
                "pain_point": "训练后肌肉紧张，需要更专业恢复",
                "main_selling_point": "多档位 + 专业按摩头 + 长续航",
                "material_version": {
                    "title": self._get_text(titles, 3),
                    "slogan": "训练后的恢复效率，也是一种战斗力。",
                    "visual": "健身房、跑步后小腿按摩、不同按摩头展示",
                    "cta": "提升运动恢复效率"
                }
            },
            {
                "segment": "女性轻量用户",
                "pain_point": "传统筋膜枪太重、太吵、操作复杂",
                "main_selling_point": "轻量机身 + AI 自动调节 + 低噪",
                "material_version": {
                    "title": self._get_text(titles, 2),
                    "slogan": "拿得住、用得顺、放松不用费力。",
                    "visual": "单手握持、包内携带、居家沙发使用",
                    "cta": "体验轻量智能放松"
                }
            },
            {
                "segment": "价格敏感但追求品质用户",
                "pain_point": "想要专业体验，但不想买太贵的高端款",
                "main_selling_point": "专业配置 + 合理价格 + 综合体验",
                "material_version": {
                    "title": self._get_text(titles, 0),
                    "slogan": f"{product_name}，把专业恢复做得更日常。",
                    "visual": "功能参数对比、价格权益、配件展示",
                    "cta": "现在入手新品优惠"
                }
            }
        ]

    def _build_testing_plan(self, segments: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {
            "test_goal": "找出不同人群下点击率和转化率最高的素材表达。",
            "test_cycle": "建议每轮 3-5 天，根据预算和流量大小调整。",
            "variables": [
                "标题角度：痛点型 / 功能型 / 对比型",
                "主视觉：办公场景 / 运动场景 / 居家场景",
                "卖点顺序：低噪优先 / 智能优先 / 续航优先",
                "CTA：立即缓解 / 提升恢复 / 新品优惠"
            ],
            "versions": [
                {
                    "version_id": f"V{i+1}",
                    "segment": seg["segment"],
                    "primary_variable": seg["main_selling_point"],
                }
                for i, seg in enumerate(segments)
            ]
        }

    def _channel_recommendations(self) -> List[Dict[str, str]]:
        return [
            {
                "channel": "抖音 / TikTok",
                "content_type": "短视频脚本 + 场景痛点开头",
                "reason": "适合展示使用前后状态变化，利于放大痛点。"
            },
            {
                "channel": "小红书",
                "content_type": "真实体验笔记 + 人群场景标题",
                "reason": "适合种草，突出低噪、轻便、办公和居家体验。"
            },
            {
                "channel": "淘宝 / 天猫",
                "content_type": "搜索标题 + 详情页卖点模块",
                "reason": "承接购买意图，需要强化参数、评价证据和优惠信息。"
            },
            {
                "channel": "信息流广告",
                "content_type": "多版本图片文案 + A/B 测试",
                "reason": "适合快速测试卖点、人群和转化链路。"
            }
        ]

    def _get_text(self, items: List[Dict[str, str]], index: int) -> str:
        if not items:
            return "新品高转化标题"
        return items[index % len(items)].get("text", "新品高转化标题")


class ReviewOptimizationAgent(BaseAgent):
    """
    复盘优化 Agent：
    根据点击率、转化率等数据自动迭代文案策略。
    """

    def run(self, ab_results: Dict[str, Any]) -> AgentResult:
        report = self._build_report(ab_results)
        summary = "已根据 A/B 测试结果完成复盘，输出下一轮优化方向。"
        return AgentResult("复盘优化 Agent", summary, report)

    def _build_report(self, ab_results: Dict[str, Any]) -> Dict[str, Any]:
        variants = ab_results.get("variants", [])
        if not variants:
            return {
                "winner": None,
                "diagnosis": "暂无可复盘数据，请先生成或导入 A/B 测试结果。",
                "next_actions": []
            }

        winner = max(variants, key=lambda x: x.get("score", 0))
        loser = min(variants, key=lambda x: x.get("score", 0))

        insights = []
        if winner.get("ctr", 0) > loser.get("ctr", 0):
            insights.append("优胜版本点击率更高，说明标题或首屏素材更能吸引目标人群。")
        if winner.get("conversion_rate", 0) > loser.get("conversion_rate", 0):
            insights.append("优胜版本转化率更高，说明卖点承接和购买理由更清晰。")
        if winner.get("cpa", 9999) < loser.get("cpa", 9999):
            insights.append("优胜版本成交成本更低，适合进入下一轮放量测试。")

        next_actions = [
            f"保留 {winner['version_id']} 的核心卖点方向：{winner.get('main_selling_point', '未知卖点')}。",
            "围绕优胜版本继续拆分变量，下一轮只测试一个变量，例如标题开头或 CTA。",
            "对低点击高转化版本优化标题和主视觉，提高流量进入效率。",
            "对高点击低转化版本优化详情页承接，增加评价证据、参数对比和限时权益。",
            "将用户评价中的高频词加入下一轮标题和短视频前 3 秒脚本。"
        ]

        return {
            "winner": winner,
            "baseline_or_loser": loser,
            "diagnosis": insights or ["当前版本差异不明显，建议增加测试样本或拉大素材差异。"],
            "next_actions": next_actions,
            "recommended_next_round": self._next_round_versions(winner)
        }

    def _next_round_versions(self, winner: Dict[str, Any]) -> List[Dict[str, str]]:
        base_segment = winner.get("segment", "目标人群")
        point = winner.get("main_selling_point", "核心卖点")
        return [
            {
                "version_id": "Next-A",
                "direction": "痛点前置",
                "copy": f"{base_segment}最怕的不是累，是酸痛一直恢复不过来。{point}，现在就试试。"
            },
            {
                "version_id": "Next-B",
                "direction": "结果承诺",
                "copy": f"从紧绷到放松，用一个更省心的恢复方案。主打：{point}。"
            },
            {
                "version_id": "Next-C",
                "direction": "评价证据",
                "copy": f"很多用户选择它，是因为它解决了真实使用中的问题：{point}。"
            }
        ]
