# 电商运营 Agent：自动生成商品文案 + 投放素材 + A/B 优化

这是一个可运行的电商运营 Agent MVP，适合用于课程作业、项目展示、Demo 演示或二次开发。

## 功能

- 商品信息解析 Agent：解析商品参数、竞品描述、用户评价
- 卖点提炼 Agent：提炼核心卖点、用户关心点、差异化优势
- 文案生成 Agent：生成标题、详情页文案、短视频脚本、广告语
- 投放策略 Agent：针对不同人群生成不同投放素材版本
- 复盘优化 Agent：根据点击率、转化率、加购率、成交成本自动给出优化建议
- A/B 测试模拟器：模拟不同文案版本的投放效果，并自动选择优胜版本

## 技术栈

- Python
- Streamlit
- Pandas
- OpenAI SDK（可选）

## 运行步骤

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 可选：配置 OpenAI API Key

如果你不配置 API Key，系统会自动使用本地规则引擎生成内容，也可以正常演示。

```bash
cp .env.example .env
```

然后在 `.env` 中填写：

```bash
OPENAI_API_KEY=你的API_KEY
OPENAI_MODEL=gpt-4o-mini
```

### 3. 启动项目

```bash
streamlit run app.py
```

浏览器打开后，即可输入商品信息并运行完整 Agent 流程。

## 项目结构

```text
ecommerce_agent_mvp/
├── app.py                    # Streamlit 页面入口
├── agents.py                 # 5 个核心 Agent
├── llm_client.py             # LLM 调用与本地 fallback
├── optimizer.py              # A/B 测试与复盘优化逻辑
├── data/
│   └── sample_product.json   # 示例商品数据
├── requirements.txt
├── .env.example
└── README.md
```

## 适合写进项目报告的亮点

本系统不是单点式的 AI 文案生成工具，而是一个围绕电商运营链路构建的多 Agent 闭环系统。它从商品信息、竞品内容和用户评价中提取结构化运营信息，再自动生成不同人群版本的标题、广告语、详情页文案和短视频脚本，并通过 A/B 测试数据对素材效果进行复盘，持续迭代优化内容策略。

## 可量化指标示例

- 素材产出效率提升：从人工 1-2 小时缩短到数分钟
- 上新周期缩短：商品资料输入后可直接生成多平台素材
- A/B 测试轮次增加：一次生成多个版本，提升测试密度
- 点击率、转化率提升：根据数据反馈自动优化标题、卖点和投放人群
