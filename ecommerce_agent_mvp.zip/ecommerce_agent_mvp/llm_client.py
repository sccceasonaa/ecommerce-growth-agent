import os
from typing import Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass


class LLMClient:
    """
    统一封装大模型调用。
    - 如果配置了 OPENAI_API_KEY，则调用 OpenAI。
    - 如果没有配置，返回 None，由 Agent 使用本地规则 fallback。
    """

    def __init__(self, model: Optional[str] = None):
        self.api_key = os.getenv("OPENAI_API_KEY", "").strip()
        self.model = model or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        self.enabled = bool(self.api_key)

    def chat(self, system_prompt: str, user_prompt: str, temperature: float = 0.7) -> Optional[str]:
        if not self.enabled:
            return None

        try:
            from openai import OpenAI
            client = OpenAI(api_key=self.api_key)

            response = client.chat.completions.create(
                model=self.model,
                temperature=temperature,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            )
            return response.choices[0].message.content
        except Exception as exc:
            return f"[LLM调用失败，已切换本地规则生成] {exc}"
