import random
from typing import Any, Dict, List

import pandas as pd


def simulate_ab_test(audience_segments: List[Dict[str, Any]], seed: int = 42) -> Dict[str, Any]:
    """
    A/B 测试模拟器。
    实际业务中，这部分数据应来自广告平台、店铺后台、埋点系统。
    这里为了 Demo，使用可复现的随机模拟生成 CTR、CVR、CPA。
    """
    random.seed(seed)

    variants = []
    for i, segment in enumerate(audience_segments):
        version_id = f"V{i + 1}"
        segment_name = segment.get("segment", f"人群{i + 1}")
        point = segment.get("main_selling_point", "核心卖点")

        impressions = random.randint(6000, 15000)

        # 根据不同人群设置稍微不同的基础表现，便于演示差异
        base_ctr = 0.018 + i * 0.002 + random.uniform(-0.004, 0.006)
        base_cvr = 0.028 + random.uniform(-0.008, 0.014)
        add_to_cart_rate = base_cvr + random.uniform(0.015, 0.035)

        clicks = int(impressions * base_ctr)
        orders = max(1, int(clicks * base_cvr))
        spend = round(impressions / 1000 * random.uniform(20, 45), 2)
        revenue = round(orders * random.uniform(260, 430), 2)
        cpa = round(spend / orders, 2)

        ctr = round(clicks / impressions, 4)
        conversion_rate = round(orders / max(clicks, 1), 4)
        roas = round(revenue / spend, 2)

        # 综合评分：点击、转化、ROAS 正向；CPA 负向
        score = round((ctr * 100 * 0.30) + (conversion_rate * 100 * 0.45) + (roas * 0.20) - (cpa / 100 * 0.05), 4)

        variants.append({
            "version_id": version_id,
            "segment": segment_name,
            "main_selling_point": point,
            "impressions": impressions,
            "clicks": clicks,
            "orders": orders,
            "spend": spend,
            "revenue": revenue,
            "ctr": ctr,
            "conversion_rate": conversion_rate,
            "add_to_cart_rate": round(add_to_cart_rate, 4),
            "cpa": cpa,
            "roas": roas,
            "score": score,
            "material": segment.get("material_version", {}),
        })

    winner = max(variants, key=lambda x: x["score"]) if variants else None
    return {
        "variants": variants,
        "winner": winner,
        "metric_explanation": {
            "ctr": "点击率 = clicks / impressions",
            "conversion_rate": "转化率 = orders / clicks",
            "cpa": "成交成本 = spend / orders",
            "roas": "广告投入产出比 = revenue / spend",
            "score": "综合评分 = CTR、转化率、ROAS、CPA 加权计算"
        }
    }


def variants_to_dataframe(ab_results: Dict[str, Any]) -> pd.DataFrame:
    variants = ab_results.get("variants", [])
    if not variants:
        return pd.DataFrame()

    rows = []
    for item in variants:
        rows.append({
            "版本": item["version_id"],
            "人群": item["segment"],
            "主卖点": item["main_selling_point"],
            "曝光": item["impressions"],
            "点击": item["clicks"],
            "订单": item["orders"],
            "花费": item["spend"],
            "收入": item["revenue"],
            "点击率": item["ctr"],
            "转化率": item["conversion_rate"],
            "加购率": item["add_to_cart_rate"],
            "CPA": item["cpa"],
            "ROAS": item["roas"],
            "综合评分": item["score"],
        })
    return pd.DataFrame(rows)
